
package ventana;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.table.DefaultTableModel;
import java.awt.Desktop;
import java.net.URI;
import javax.swing.JOptionPane;


public class Boletas extends javax.swing.JFrame {

    
    public Boletas() {
        initComponents();
        this.setLocationRelativeTo(null);
        mostrarDatos("");
        
    }
    
    void mostrarDatos(String id){
        DefaultTableModel modelo=new DefaultTableModel();
        modelo.addColumn("NOMBRE");
        modelo.addColumn("APELLIDO");
        modelo.addColumn("IDENTIFICACION");
        modelo.addColumn("DIRECCION");
        modelo.addColumn("CORREO");
        tbregistro.setModel(modelo);
        String sql="";
        if (id.equals(""))
        {
            sql="";
        }
        else
            sql = "SELECT * FROM registro WHERE identificacion='"+id+"'";
        
        String []datos = new String [5];
        try {
            Statement st = nm.createStatement();
            ResultSet rs = st.executeQuery(sql);
            while(rs.next()){
                datos[0]=rs.getString(1);
                datos[1]=rs.getString(2);
                datos[2]=rs.getString(3);
                datos[3]=rs.getString(4);
                datos[4]=rs.getString(5);
                modelo.addRow(datos);
                
            }
            tbregistro.setModel(modelo);
        } catch (SQLException ex) {
            Logger.getLogger(Boletas.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        busq = new javax.swing.JTextField();
        buscar = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tbregistro = new javax.swing.JTable();
        pse = new javax.swing.JLabel();
        visa = new javax.swing.JLabel();
        master = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("BOLETAS");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 30, -1, -1));

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Ingrese ID:");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 80, -1, -1));
        getContentPane().add(busq, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 70, 220, 30));

        buscar.setBackground(new java.awt.Color(0, 153, 255));
        buscar.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        buscar.setForeground(new java.awt.Color(51, 93, 201));
        buscar.setText("Buscar");
        buscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buscarActionPerformed(evt);
            }
        });
        getContentPane().add(buscar, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 80, -1, -1));

        tbregistro.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        tbregistro.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbregistroMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tbregistro);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 110, 570, 50));

        pse.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagen/pse1.png"))); // NOI18N
        pse.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                pseMouseClicked(evt);
            }
        });
        getContentPane().add(pse, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 250, -1, 70));

        visa.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagen/visa1.png"))); // NOI18N
        visa.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                visaMouseClicked(evt);
            }
        });
        getContentPane().add(visa, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 240, -1, -1));

        master.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagen/master1.png"))); // NOI18N
        master.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                masterMouseClicked(evt);
            }
        });
        getContentPane().add(master, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 250, -1, -1));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagen/resize-img.jpg"))); // NOI18N
        jLabel1.setText("jLabel1");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 600, 396));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void buscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buscarActionPerformed
        mostrarDatos(busq.getText());
        
    }//GEN-LAST:event_buscarActionPerformed

    private void tbregistroMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbregistroMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_tbregistroMouseClicked

    private void pseMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_pseMouseClicked
        
        try {
            Desktop.getDesktop().browse(new URI ("https://www.pse.com.co/inicio"));
        }catch (Exception ex){
            JOptionPane.showMessageDialog(null,"ERROR, no se puede ejecutar la accion");
        }
           
        
    }//GEN-LAST:event_pseMouseClicked

    private void visaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_visaMouseClicked
         try {
            Desktop.getDesktop().browse(new URI ("https://www.visa.com.co/"));
        }catch (Exception ex){
            JOptionPane.showMessageDialog(null,"ERROR, no se puede ejecutar la accion");
        }
    }//GEN-LAST:event_visaMouseClicked

    private void masterMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_masterMouseClicked
       try {
            Desktop.getDesktop().browse(new URI ("http://www.mastercard.com/co/consumidores/index.html"));
        }catch (Exception ex){
            JOptionPane.showMessageDialog(null,"ERROR, no se puede ejecutar la accion");
        }
        
        
    }//GEN-LAST:event_masterMouseClicked

    
    public static void main(String args[]) {
       
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Boletas().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton buscar;
    private javax.swing.JTextField busq;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel master;
    private javax.swing.JLabel pse;
    private javax.swing.JTable tbregistro;
    private javax.swing.JLabel visa;
    // End of variables declaration//GEN-END:variables
conectar nom=new conectar();
        Connection nm= nom.conexion();
}
